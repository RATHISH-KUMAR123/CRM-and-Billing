<?php
//alias Contacts
$myCtrl = 'customers';
require('application/controllers/contacts.php');