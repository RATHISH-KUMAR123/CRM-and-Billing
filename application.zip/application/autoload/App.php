<?php

class App
{
    public static function run()
    {
        return true;
    }
}
