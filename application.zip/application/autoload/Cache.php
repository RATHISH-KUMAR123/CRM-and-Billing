<?php
class Cache
{
    public static function save()
    {
        return;
    }
}
